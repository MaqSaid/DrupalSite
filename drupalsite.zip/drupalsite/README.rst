A very basic Drupal On-line Shopping Site for testing and proof of concept kind of things.

To deploy this codebase import drupaldb.zip file into a MySQL database and point enter
appropriate database details into settings.php.

Use the DrupalSite.zip to setup Local Drupal Environment.

The codebase is developed on Drupal 7.54 and PHP 5.6 and should work with PHP 5.4 or higher.

1) The Site should allow you to login as authorised user id maq1 and password maq and buy product of type membership

2) You can also login as admin or maq with password maq and buy a product of type membership and perform all admin options.

3) The step to be followed are explained in detail in the Specification Document.
