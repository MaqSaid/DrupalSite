#!/bin/sh

/usr/bin/lynx -source http://example.com/cron.php > /dev/null 2>&1
